function  res=d2_array(varargin)
%function res=[[var1],[var2],[var3...]
%******** ******
%**
global I2M_array

I2M_array=2;
res=d1_array(varargin{:});

