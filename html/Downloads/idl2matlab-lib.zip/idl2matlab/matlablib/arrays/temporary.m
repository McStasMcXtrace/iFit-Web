function ret=temporary(var)
%function temporary(var)
%******** *********
%**
ret=var;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

