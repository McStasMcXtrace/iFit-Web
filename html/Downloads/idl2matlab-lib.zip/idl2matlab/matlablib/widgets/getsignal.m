function getsignal(varargin)
%******* *********
%**
%disp('in S');
widget_signal(0);
