function setSignal(varargin)

%disp(['pause' freq 'sec']);
widget_signal(0);
