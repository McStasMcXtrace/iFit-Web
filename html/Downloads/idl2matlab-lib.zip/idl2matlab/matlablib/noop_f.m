%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%                    IDL2SCILAB Project
%
% --------------------------------------------------------
%   ILL (Institut Laue Langevin)
%
%   38000 GRENOBLE Cedex
% --------------------------------------------------------
% Fonction : function noop_f
%            ne fait rien (retourne 1)
%            fonction appelee pour simuler l'appel a une
%            fonction non encore traduite dans la base
%            de connaissances
%
% Auteurs :
%                 Didier Richard
% Date creation : ?
% Modifications : 07 / 07 / 2003
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function  res=noop_f(varargin)
%********     ******
%**
res=1;
