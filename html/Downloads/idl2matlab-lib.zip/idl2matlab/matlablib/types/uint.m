function  num=uint(val)
%function uint(val)
%******** ****
%**
if nargin ~=1, disp('!!! uint.m has to be completed...'); end;

 num=long  (val);
%num=uint16(num);
