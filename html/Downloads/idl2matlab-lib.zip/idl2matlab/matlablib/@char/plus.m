function c = plus(a,b)

c = [a b];
