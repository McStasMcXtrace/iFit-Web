%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%                    IDL2SCILAB Project
%
% --------------------------------------------------------
%   ILL (Institut Laue Langevin)
%
%   38000 GRENOBLE Cedex
% --------------------------------------------------------
% Fonction : procedure noop_p
%            ne fait rien
%            procedure appelee pour simuler l'appel a une
%            procedure non encore traduite dans la base
%            de connaissances
%
% Auteurs :
%                 Didier Richard
% Date creation : ?
% Modifications : 07 / 07 / 2003
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function  noop_p(varargin)
%******** ******
%**
