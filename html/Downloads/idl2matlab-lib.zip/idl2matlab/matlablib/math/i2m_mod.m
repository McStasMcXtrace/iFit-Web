function c=i2m_mod(a,b)

c=mod(abs(a),abs(b));
if a < 0, c=-c;  end;
