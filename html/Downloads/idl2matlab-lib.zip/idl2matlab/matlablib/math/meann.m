function res=mean(val)
%*******     ****
%**

res=total(val)/length(val);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
