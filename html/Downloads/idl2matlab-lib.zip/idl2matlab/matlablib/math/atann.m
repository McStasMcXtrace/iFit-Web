function res=atann(a, b)
%*******     *****

if nargin == 1, res=atan(a); else, res=atan2(a,b); end;
