function res=uniq(vect,index)
%*******     ****
%**

[b,res,n] = unique(vect,'rows');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
