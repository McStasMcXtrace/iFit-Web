function c = plus(a,b)

c = double(a) + double(b);
