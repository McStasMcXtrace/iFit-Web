function c = rem(a,b)
  c = rem(double(a),double(b));

