function c = uminus(a)

c = int32(builtin('uminus',double(a)));
