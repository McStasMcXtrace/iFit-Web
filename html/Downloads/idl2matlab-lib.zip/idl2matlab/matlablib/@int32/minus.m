function c = minus(a,b)

c = double(a) - double(b);
