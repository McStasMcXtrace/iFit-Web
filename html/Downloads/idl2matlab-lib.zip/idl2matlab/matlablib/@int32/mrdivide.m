function c = rdivide(a,b)

disp('plo')

