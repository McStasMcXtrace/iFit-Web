function c = power(a,b)

if (round(a) == a & round(b) == b) c = round(builtin('power',a,b));end
