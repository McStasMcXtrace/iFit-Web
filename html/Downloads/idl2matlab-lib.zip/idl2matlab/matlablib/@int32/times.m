function c = times(a,b)

c = double(a) .* double(b);
