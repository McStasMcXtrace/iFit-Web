function c = gt(a,b)

d = creer_array_gt(a,b);

c = reshape(d, size(a));
