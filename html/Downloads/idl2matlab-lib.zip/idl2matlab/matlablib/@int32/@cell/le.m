function c = le(a,b)

d = creer_array_le(a,b);

c = reshape(d, size(a));
