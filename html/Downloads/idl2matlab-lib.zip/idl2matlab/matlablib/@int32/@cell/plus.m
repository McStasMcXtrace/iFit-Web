function c = plus(a,b)

d = creer_array_plus(a,b);

c = reshape(d, size(a));
