function c = ge(a,b)

d = creer_array_ge(a,b);

c = reshape(d, size(a));
