function c = lt(a,b)

d = creer_array_lt(a,b);

c = reshape(d, size(a));
