function c = eq(a,b)

d = creer_array_eq(a,b);

c = reshape(d, size(a));
