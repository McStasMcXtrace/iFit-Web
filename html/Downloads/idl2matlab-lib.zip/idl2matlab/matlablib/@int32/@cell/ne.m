function c = ne(a,b)

d = creer_array_ne(a,b);

c = reshape(d, size(a));
